#!/bin/bash

# Input FASTA file
fasta_file=${1}

# Output directory for FST files
output_dir="output_fsts"

# Create output directory if it doesn't exist
mkdir -p "$output_dir"

# Extract amino acid sequences from FASTA file
awk '/^>/ {if (seq) {print seq}; printf("%s\t",$0); seq=""; next} {seq = seq $0} END {print seq}' "$fasta_file" |
while IFS=$'\t' read -r header sequence; do
    # Remove '>' from header
    name="${header#>}"
    # Create FST file
    echo -e "$sequence" > "$output_dir/$name.fst"
done

echo "Individual FST files created in $output_dir."