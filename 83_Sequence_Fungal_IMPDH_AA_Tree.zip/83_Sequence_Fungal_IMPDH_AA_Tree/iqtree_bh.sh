#!/bin/bash

( iqtree -s ${1} -te ${2} -st AA -nt 10 -m LG+FO+G12 -blscale -abayes -asr | tee ${1%.*}_iqtree.log ) &
