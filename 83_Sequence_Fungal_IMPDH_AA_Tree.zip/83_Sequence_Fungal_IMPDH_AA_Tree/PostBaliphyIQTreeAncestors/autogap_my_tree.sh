#!/bin/bash

ALN=${1}
TREE=${2}
ALNROOT=${ALN%.*}
MODEL='LG+FO+G12'
#MODEL='Poisson+FQ'
BINMODEL='GTR2+FO+G8'

# first do a normal iqtree run to get a phylogeny based on protein sequences
# and the ancestral reconstructions of the protein sequences (ungapped)
nice iqtree2 -s ${ALN} -te ${TREE} -st AA -nt 6 -m ${MODEL} -asr

BINALN=${ALNROOT}_binary.a2m

# convert the alignment to binary (0 for gaps, 1 for an amino acid)
# seqcon -w ${ALN}
# this sed command only works for FASTA files
sed -e '/^>/ !s/[^-]/1/g' -e '/^>/ !s/-/0/g' ${ALN} > ${BINALN}

# get rid of branch supports, iqtree puts them in the node name when it reads its own tree format!
perl -p -e 's/\/\/[^:]*//g' ${TREE} > ${TREE}_nobs.treefile

# now run iqtree with the protein phylogeny and the binary alignment, and reconstruct
# binary gap states for the ancestral nodes
nice iqtree2 -s ${BINALN} -nt 6 -st BIN -m ${BINMODEL} -asr -te ${TREE}_nobs.treefile 

# give ancprobs both ancestral state files, one for protein sequence and one for the binary gap states
# cat binary.a2m.state | perl -p -e 's/\/\/[^\s]*//' > binary2.a2m.state  # gets rid of "\\0.9" etc branch supports in node name
#ancprobs -n 96 -p iqtree -f ${ALN}.state -b ${BINALN}.state


