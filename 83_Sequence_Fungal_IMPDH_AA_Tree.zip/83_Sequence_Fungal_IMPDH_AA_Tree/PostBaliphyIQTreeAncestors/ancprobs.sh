for i in 63 77 76 78 75 71 68 62 31 54 49 42 19 34 18 43 14 35 21
do
	printf $i
	ancprobs -n $i -p iqtree -f ${1} -b ${2} > Node_$i/node_$i.stats.out
	mkdir Node_$i
	mv *node_$i* Node_$i
done
