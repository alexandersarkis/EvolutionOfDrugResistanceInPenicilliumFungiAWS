ANC_STATE=${1}
BIN_STATE=${2}
for i in 81
do
	mkdir Node_${i}
	printf ${i}
	ancprobs -n  ${i} -p iqtree2 -f ${ANC_STATE} -b ${BIN_STATE} > Node_$i/node_$i.stats.out
	mv *node_$i* Node_$i
done
