for i in 63 77 76 78 75 71 68 62 31 54 49 42 19 34 18 43 14 35 21
do
	printf $i
	mkdir Node_$i
	mv *node_$i* Node_$i*
done
