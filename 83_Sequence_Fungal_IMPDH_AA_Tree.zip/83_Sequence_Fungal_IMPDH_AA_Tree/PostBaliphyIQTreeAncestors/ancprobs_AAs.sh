ANC_STATE=${1}
BIN_STATE=${2}
for i in 81 80 79 78 76 72 68 65 64 63 60 55 50 44 31
do
	mkdir Node_${i}
	printf ${i}
	ancprobs -n ${i} -p iqtree2 -f ${ANC_STATE} -b ${BIN_STATE} > Node_$i/node_$i.stats.out
	mv *node_$i* Node_$i
done
