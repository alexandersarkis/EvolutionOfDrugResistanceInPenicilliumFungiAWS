#!/bin/bash

#Cats gi.fst files into a file named aas.fasta, replacing the gi with the 
#human readable label created in gi2human.sh during this process
function humanreplace()
{
    local GI=${1};
    local HUMANID;

    HUMANID=$(egrep "^ *${GI} " newgikey.txt | awk '{ print $3 }');
    cat ${GI}.fst | perl -pe "s/^>.*/>${HUMANID}/" >> 12_16_21_IMPDH_AA_Tree_SeqsNamed.fasta;
}

#This script is supposed to follow gi2human.sh and the output of that
#script (gikey.txt) must be present in the directory where you will be
#performing humanreplacegi.sh & where the gi.fst files from getblast.sh
#are located
#CMD LINE: humanreplacegi.sh

GIS=$(awk '{ print $1 }' newgikey.txt);

rm -f aas.fasta;

for GI in ${GIS}
do
    humanreplace ${GI};
done

