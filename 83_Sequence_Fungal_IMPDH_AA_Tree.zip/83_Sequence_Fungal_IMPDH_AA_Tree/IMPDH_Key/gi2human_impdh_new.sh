#!/bin/bash

#Searches FASTA title to construct a human readable label
function readable()
{
    local FSTFILE=${1};
    local ANNOTATION;
    local GI;
    local NAME;
    local ORGAN;
    local LABEL;
    local COUNT;
    local TEMP;

    #Pull out the FASTA annotation line & remove parentheses from this line
    ANNOTATION=$(egrep '^>' ${FSTFILE} | perl -pe 's/[()]//g');
#    echo ${ANNOTATION}
#    return;

    #Pull out & save the GI # from the annotation line
    GI=$(echo ${ANNOTATION} | perl -pe 's/^>([^ ]*) .*\n/$1/');

#    echo ${GI}
#    return;

    if [ -e newgikey.txt ] && egrep ${GI} newgikey.txt
    then
       return 1;
    fi

    #Creates a variable (NAME) that is made of the first 2 letters of the first words within
    #brackets on the FASTA title line, if no brackets NAME is assigned as UNKN
    #NAME is usually made from the species name
    if echo ${ANNOTATION} | egrep -q '\['
    then
        NAME=$(echo ${ANNOTATION} | perl -pe 's/^>[^[]*\[([[:alnum:]][[:alnum:]])[^ ]* ([[:alnum:]][[:alnum:]])[^]]*\].*/\U$1$2/');
    else
        NAME="UNKN";
    fi

    if [ ${#NAME} -ne 4 ]
    then
        if echo ${ANNOTATION} | egrep -q '\['
        then
            NAME=$(echo ${ANNOTATION} | perl -pe 's/^>[^[]*\[([[:alnum:]][[:alnum:]])[^]]*\].*/\U$1/');
        else
            NAME="UNKN";
        fi
    fi

    #Test if NAME is 4 characters long and if not assign as UNKN
    if [ ${#NAME} -ne 2 ] && [ ${#NAME} -ne 4 ]
    then
        NAME="UNKN";
    fi

#    echo "${FSTFILE} ${GI} ${NAME}";
#    return;

    #The following if loop is used to assign the variable ORGAN by checking each FASTA
    #title for specific organellular information.
#    if echo ${ANNOTATION} | egrep -qi 'hypothetical'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'IMP'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'inosine'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'Aldolase'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'putative'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'Inosine'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'Putative'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'Probable'
#    then
#       ORGAN="IMPDH";
#    elif echo ${ANNOTATION} | egrep -qi 'IMPDH'
#    then
#       ORGAN="IMPDH";
#    else
#       ORGAN="_";
#    fi

    #The following if loops are used to assign the variable LABEL. The first if checks to
    #see if the FASTA has a sp ID and uses that as the name. If no sp ID exists, then the
    #if loops make a sp-styled ID for the gi #.
    if echo ${ANNOTATION} | egrep -qi 'hypothetical'
    then
		LABEL="IMPDH_${NAME}";
	elif echo ${ANNOTATION} | egrep -qi 'IMP'
	then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'inosine'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'Aldolase'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'putative'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'Inosine'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'Putative'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'Probable'
    then
		LABEL="IMPDH_${NAME}";
    elif echo ${ANNOTATION} | egrep -qi 'IMPDH'
    then
		LABEL="IMPDH_${NAME}";
    else
        LABEL="UNK_${NAME}";
    fi 
    
    #Creates variable COUNT which is used to ensure that each LABEL is unique by appending
    #COUNT to the LABEL if there is another LABEL with that id
    if [ -e newgikey.txt ]
    then 
       COUNT=$(awk '{print $2}' newgikey.txt | egrep ${LABEL} | wc -l)
    else
       COUNT=0
    fi

    if [ ${COUNT} -ge 1 ] && [ ${COUNT} -lt 100 ]
    then
        TEMP=$(echo ${LABEL} | perl -pe 's/(.{10}).*/$1/');
        printf "%15s %15s %15s%d\n" ${GI} ${LABEL} ${TEMP} ${COUNT} >> newgikey.txt;
    elif [ ${COUNT} -ge 100 ]
    then
        TEMP=$(echo ${LABEL} | perl -pe 's/(.{9}).*/$1/');
        printf "%15s %15s %15s%d\n" ${GI} ${LABEL} ${TEMP} ${COUNT} >> newgikey.txt;
    else
        TEMP=$(echo ${LABEL} | perl -pe 's/(.{12}).*/$1/');
        printf "%15s %15s %15s\n" ${GI} ${LABEL} ${TEMP} >> newgikey.txt;
    fi

    return 0;
}

#GIKEYFILE=${1};

#cp ${GIKEYFILE} newgikey.txt

rm newgikey.txt

for FSTFILE in *.fst
do
    readable ${FSTFILE};
done


