#!/bin/bash

FILE=${1};

( nice bali-phy --align ${FILE} --alphabet Amino-Acids --smodel lg08+f+Rates.gamma --imodel RS07 --iterations=100000000 & > ${FILE%.*}.log ) &
( nice bali-phy --align ${FILE} --alphabet Amino-Acids --smodel lg08+f+Rates.gamma --imodel RS07 --iterations=100000000 & > ${FILE%.*}.log ) &
( nice bali-phy --align ${FILE} --alphabet Amino-Acids --smodel lg08+f+Rates.gamma --imodel RS07 --iterations=100000000 & > ${FILE%.*}.log ) &

